# Aniyomi app preview builds

![Build job](https://github.com/jmir1/aniyomi-preview/workflows/Build%20job/badge.svg) [![Latest build](https://img.shields.io/github/v/release/jmir1/aniyomi-preview.svg?maxAge=3600&label=Latest%20build)](https://github.com/jmir1/aniyomi-preview/releases)

This repository houses the preview builds for [Aniyomi](https://github.com/jmir1/aniyomi).

For downloads, see [Releases](https://github.com/jmir1/aniyomi-preview/releases).
